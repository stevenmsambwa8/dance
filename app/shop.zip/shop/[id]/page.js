'use client'
import { useState, useEffect, useRef } from 'react'
import { useParams, useSearchParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { useAuth } from '../../../components/AuthProvider'
import { supabase } from '../../../lib/supabase'
import styles from './page.module.css'
import UserBadges from '../../../components/UserBadges'
import usePageLoading from '../../../components/usePageLoading'

export default function ShopItemDetail() {
  const { id } = useParams()
  const searchParams = useSearchParams()
  const { user } = useAuth()
  const router = useRouter()

  const [item, setItem]             = useState(null)
  const [images, setImages]         = useState([])
  const [loading, setLoading]       = useState(true)
  usePageLoading(loading)

  // Gallery
  const [activeIdx, setActiveIdx]   = useState(0)
  const [zoom, setZoom]             = useState(false)
  const [zoomScale, setZoomScale]   = useState(1)
  const [zoomOrigin, setZoomOrigin] = useState({ x: 50, y: 50 })
  const [lightbox, setLightbox]     = useState(false)
  const [lbIdx, setLbIdx]           = useState(0)
  const [imgDims, setImgDims]       = useState({})
  const stripRef = useRef(null)

  // Request / chat
  const [myRequest, setMyRequest]     = useState(null)
  const [allRequests, setAllRequests] = useState([])
  const [myProfile, setMyProfile]     = useState(null)

  // Chat panel
  const [chatOpen, setChatOpen]   = useState(false)
  const [offerPrice, setOfferPrice] = useState('')
  const [offerNote, setOfferNote]   = useState('')
  const [sending, setSending]       = useState(false)
  const [sendError, setSendError]   = useState('')

  // Buy Now modal
  const [buyModal, setBuyModal] = useState(false)

  // Seller inbox
  const [updating, setUpdating] = useState(false)

  const isSeller = item && user && user.id === item.seller_id

  // Open buy modal from listing page (?buy=1)
  useEffect(() => {
    if (searchParams.get('buy') === '1' && item && !isSeller && user) {
      setBuyModal(true)
    }
  }, [searchParams, item, isSeller, user])

  // Fetch own profile
  useEffect(() => {
    if (!user) return
    supabase.from('profiles').select('username').eq('id', user.id).single()
      .then(({ data }) => setMyProfile(data || null))
  }, [user])

  // Fetch item + images
  useEffect(() => {
    async function load() {
      setLoading(true)
      const [{ data: itemData }, { data: imgData }] = await Promise.all([
        supabase
          .from('shop_items')
          .select('id, seller_id, title, price, category, description, active, created_at, profiles(username, tier, level, avatar_url, email)')
          .eq('id', id)
          .single(),
        supabase
          .from('shop_item_images')
          .select('url, sort_order')
          .eq('item_id', id)
          .order('sort_order', { ascending: true }),
      ])
      setItem(itemData || null)
      setImages(imgData?.map(i => i.url) || [])
      setLoading(false)
    }
    load()
  }, [id])

  // Requests realtime / polling
  useEffect(() => {
    if (!item || !user) return
    if (isSeller) {
      loadAllRequests()
      const ch = supabase
        .channel(`buy-requests-${id}`)
        .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'buy_requests', filter: `item_id=eq.${id}` }, loadAllRequests)
        .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'buy_requests', filter: `item_id=eq.${id}` }, loadAllRequests)
        .subscribe()
      return () => supabase.removeChannel(ch)
    } else {
      loadMyRequest()
    }
  }, [item, user, isSeller])

  async function loadMyRequest() {
    const { data } = await supabase
      .from('buy_requests')
      .select('*, profiles(username)')
      .eq('item_id', id)
      .eq('buyer_id', user.id)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()
    setMyRequest(data || null)
  }

  async function loadAllRequests() {
    const { data } = await supabase
      .from('buy_requests')
      .select('id, item_id, buyer_id, seller_id, offer_price, note, status, created_at, profiles!buy_requests_buyer_id_fkey(username, tier, avatar_url, email)')
      .eq('item_id', id)
      .order('created_at', { ascending: false })
    setAllRequests(data || [])
  }

  async function sendRequest() {
    if (!user) return
    if (!offerPrice) { setSendError('Enter your offer price'); return }
    if (!offerNote.trim()) { setSendError('Add a message for the seller'); return }
    setSendError('')
    setSending(true)
    const { data: req, error } = await supabase
      .from('buy_requests')
      .insert({
        item_id: id,
        buyer_id: user.id,
        seller_id: item.seller_id,
        offer_price: Number(offerPrice),
        note: offerNote,
        status: 'pending',
      })
      .select()
      .single()
    if (error) { setSendError(error.message); setSending(false); return }
    const senderName = myProfile?.username || user.email?.split('@')[0]
    await supabase.from('notifications').insert({
      user_id: item.seller_id,
      type: 'buy_request',
      title: 'New buy request',
      body: `${senderName} wants to buy "${item.title}" for TZS ${offerPrice}`,
      meta: { request_id: req.id, item_id: id },
      read: false,
    })
    setSending(false)
    setMyRequest(req)
    setChatOpen(false)
  }

  async function updateRequestStatus(reqId, status, buyerId) {
    setUpdating(true)
    await supabase.from('buy_requests').update({ status }).eq('id', reqId)
    await supabase.from('notifications').insert({
      user_id: buyerId,
      type: 'request_update',
      title: status === 'accepted' ? 'Offer accepted!' : 'Offer declined',
      body: status === 'accepted'
        ? `Your offer on "${item.title}" was accepted.`
        : `Your offer on "${item.title}" was declined.`,
      meta: { request_id: reqId, item_id: id },
      read: false,
    })
    await loadAllRequests()
    setUpdating(false)
  }

  // Zoom handlers
  function handleMainClick(e) {
    if (!zoom) {
      const rect = e.currentTarget.getBoundingClientRect()
      setZoomOrigin({
        x: ((e.clientX - rect.left) / rect.width) * 100,
        y: ((e.clientY - rect.top) / rect.height) * 100,
      })
      setZoomScale(2.5)
      setZoom(true)
    } else {
      setZoom(false)
      setZoomScale(1)
    }
  }
  function handleMainMove(e) {
    if (!zoom) return
    const rect = e.currentTarget.getBoundingClientRect()
    setZoomOrigin({
      x: ((e.clientX - rect.left) / rect.width) * 100,
      y: ((e.clientY - rect.top) / rect.height) * 100,
    })
  }

  // Preload natural image dimensions for adaptive aspect ratio
  useEffect(() => {
    const src = images[activeIdx]
    if (!src || imgDims[src]) return
    const img = new Image()
    img.onload = () => setImgDims(d => ({ ...d, [src]: { w: img.naturalWidth, h: img.naturalHeight } }))
    img.src = src
  }, [activeIdx, images])

  // Lightbox keyboard nav
  useEffect(() => {
    if (!lightbox) return
    const handler = (e) => {
      if (e.key === 'ArrowRight') setLbIdx(i => (i + 1) % images.length)
      if (e.key === 'ArrowLeft')  setLbIdx(i => (i - 1 + images.length) % images.length)
      if (e.key === 'Escape')     setLightbox(false)
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [lightbox, images.length])

  function scrollStripTo(idx) {
    setActiveIdx(idx)
    setZoom(false)
    setZoomScale(1)
    stripRef.current?.children[idx]?.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' })
  }

  const statusColor = (s) => ({ pending: '#f59e0b', accepted: '#22c55e', declined: '#ef4444', completed: '#6366f1' }[s] || '#888')
  const fmtPrice = (p) => { const n = Number(String(p || '').replace(/[^0-9.]/g, '')); return isNaN(n) || n <= 0 ? p : n.toLocaleString() }

  // Adaptive aspect ratio
  const activeSrc  = images[activeIdx]
  const dims       = activeSrc ? imgDims[activeSrc] : null
  const aspectRatio = dims ? `${dims.w} / ${dims.h}` : '1 / 1'

  if (loading) return null
  if (!item)   return (
    <div className={styles.notFound}>
      <h2>Item not found</h2>
      <Link href="/shop">← Back to shop</Link>
    </div>
  )

  return (
    <div className={styles.page}>
      <Link href="/shop" className={styles.back}>
        <i className="ri-arrow-left-line" /> All listings
      </Link>

      <div className={styles.layout}>

        {/* ── LEFT ── */}
        <div className={styles.left}>

          {/* Gallery */}
          {images.length > 0 ? (
            <div className={styles.gallery}>
              <div
                className={`${styles.mainImg} ${zoom ? styles.mainImgZoomed : ''}`}
                style={{ aspectRatio }}
                onClick={handleMainClick}
                onMouseMove={handleMainMove}
                onMouseLeave={() => { setZoom(false); setZoomScale(1) }}
                title={zoom ? 'Click to zoom out' : 'Click to zoom in'}
              >
                <img
                  src={images[activeIdx]}
                  alt={item.title}
                  style={{
                    transformOrigin: zoom ? `${zoomOrigin.x}% ${zoomOrigin.y}%` : 'center',
                    transform: `scale(${zoomScale})`,
                    transition: zoom ? 'transform 0.15s ease' : 'transform 0.2s ease',
                  }}
                />
                {!zoom && <span className={styles.zoomHint}><i className="ri-zoom-in-line" /> Zoom</span>}
                <button
                  className={styles.expandBtn}
                  onClick={e => { e.stopPropagation(); setLbIdx(activeIdx); setLightbox(true) }}
                >
                  <i className="ri-fullscreen-line" />
                </button>
                {images.length > 1 && (
                  <>
                    <button
                      className={`${styles.galleryArrow} ${styles.galleryArrowL}`}
                      onClick={e => { e.stopPropagation(); scrollStripTo((activeIdx - 1 + images.length) % images.length) }}
                    >
                      <i className="ri-arrow-left-s-line" />
                    </button>
                    <button
                      className={`${styles.galleryArrow} ${styles.galleryArrowR}`}
                      onClick={e => { e.stopPropagation(); scrollStripTo((activeIdx + 1) % images.length) }}
                    >
                      <i className="ri-arrow-right-s-line" />
                    </button>
                  </>
                )}
              </div>

              {images.length > 1 && (
                <div className={styles.strip} ref={stripRef}>
                  {images.map((src, i) => (
                    <button
                      key={i}
                      className={`${styles.thumb} ${i === activeIdx ? styles.thumbActive : ''}`}
                      onClick={() => scrollStripTo(i)}
                    >
                      <img src={src} alt={`Photo ${i + 1}`} />
                    </button>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className={styles.noImg}>
              <i className="ri-image-line" />
              <span>No photos</span>
            </div>
          )}

          {/* Product Info */}
          <div className={styles.productInfo}>
            <span className={styles.catBadge}>{item.category}</span>
            <h1 className={styles.title}>{item.title}</h1>
            <div className={styles.priceRow}>
              <span className={styles.price}>TZS {fmtPrice(item.price)}</span>
              <span className={item.active ? styles.status_active : styles.status_sold}>
                {item.active ? 'Available' : 'Sold'}
              </span>
            </div>

            <div className={styles.divider} />
            <div className={styles.section}>
              <p className={styles.sectionLabel}>Description</p>
              <p className={styles.desc}>{item.description || 'No description provided.'}</p>
            </div>

            <div className={styles.divider} />
            <div className={styles.section}>
              <p className={styles.sectionLabel}>Seller</p>
              <Link href={`/profile/${item.seller_id}`} className={styles.sellerRow}>
                <div className={styles.sellerAvatarWrap}>
                  {item.profiles?.avatar_url
                    ? <img src={item.profiles.avatar_url} className={styles.sellerAvatarImg} alt="" />
                    : <span>{item.profiles?.username?.[0]?.toUpperCase() || '?'}</span>
                  }
                </div>
                <div>
                  <p className={styles.sellerName}>
                    {item.profiles?.username || 'Unknown'}
                    <UserBadges
                      email={item.profiles?.email}
                      countryFlag={item.profiles?.country_flag}
                      isSeasonWinner={item.profiles?.is_season_winner}
                      size={13}
                      gap={2}
                    />
                  </p>
                  {item.profiles?.tier && (
                    <p className={styles.sellerTier}>{item.profiles.tier} · Lv.{item.profiles.level ?? 1}</p>
                  )}
                </div>
              </Link>
            </div>
          </div>
        </div>

        {/* ── RIGHT ── */}
        <div className={styles.right}>

          {/* Price + CTAs panel */}
          <div className={styles.panel}>
            <div className={styles.panelPriceRow}>
              <span className={styles.panelPrice}>TZS {fmtPrice(item.price)}</span>
              <span className={`${styles.panelStatus} ${item.active ? styles.panelStatusAvail : styles.panelStatusSold}`}>
                {item.active ? '● Available' : '● Sold'}
              </span>
            </div>

            {/* Buyer CTAs */}
            {!isSeller && user && item.active && (
              <>
                {/* No request yet — initial state */}
                {!myRequest && !chatOpen && (
                  <button className={styles.buyNowBtn} onClick={() => router.push(`/shop/${id}/request/new`)}>
                    Buy Now
                  </button>
                )}

                {/* Request form */}
                {!myRequest && chatOpen && (
                  <div className={styles.chatPanel}>
                    <div className={styles.chatPanelHeader}>
                      <span><i className="ri-chat-3-line" /> Send a Request</span>
                      <button className={styles.chatPanelClose} onClick={() => { setChatOpen(false); setSendError('') }}>
                        <i className="ri-close-line" />
                      </button>
                    </div>
                    <div className={styles.field}>
                      <label>Your Offer Price (TZS)</label>
                      <input
                        type="number"
                        placeholder={`Asking: ${item.price}`}
                        value={offerPrice}
                        onChange={e => setOfferPrice(e.target.value)}
                      />
                    </div>
                    <div className={styles.field}>
                      <label>Message <span className={styles.required}>*required</span></label>
                      <textarea
                        rows={3}
                        placeholder="Introduce yourself and explain your interest…"
                        value={offerNote}
                        onChange={e => setOfferNote(e.target.value)}
                      />
                    </div>
                    {sendError && (
                      <p style={{ fontSize: 12, color: '#ef4444', margin: '-4px 0' }}>{sendError}</p>
                    )}
                    <button className={styles.primaryBtn} onClick={sendRequest} disabled={sending}>
                      {sending ? 'Sending…' : <><i className="ri-send-plane-line" /> Send Request</>}
                    </button>
                  </div>
                )}

                {/* Request already sent */}
                {myRequest && (
                  <>
                    <div className={styles.requestStatus}>
                      <span>Request status</span>
                      <strong style={{ color: statusColor(myRequest.status) }}>
                        {myRequest.status?.toUpperCase()}
                      </strong>
                    </div>
                    <div className={styles.offerSummary}>
                      <span>Your offer</span>
                      <strong>TZS {Number(myRequest.offer_price).toLocaleString()}</strong>
                    </div>
                    {myRequest.note && (
                      <p className={styles.offerNote}>&quot;{myRequest.note}&quot;</p>
                    )}
                    <Link
                      href={`/shop/${id}/request/${myRequest.id}`}
                      className={styles.primaryBtn}
                      style={{ textAlign: 'center' }}
                    >
                      <i className="ri-chat-3-line" /> View Details & Chat
                    </Link>
                    {myRequest.status === 'declined' && (
                      <button
                        className={styles.secondaryBtn}
                        onClick={() => router.push(`/shop/${id}/request/new`)}
                      >
                        <i className="ri-refresh-line" /> Send a New Request
                      </button>
                    )}
                  </>
                )}
              </>
            )}

            {isSeller && (
              <p className={styles.panelSub}>This is your listing.</p>
            )}

            {!user && (
              <>
                <p className={styles.panelTitle}>Interested in this item?</p>
                <p className={styles.panelSub}>Log in to chat with the seller or make an offer.</p>
                <Link href="/login" className={styles.primaryBtn} style={{ textAlign: 'center', display: 'flex' }}>
                  <i className="ri-login-box-line" /> Log In to Buy
                </Link>
              </>
            )}
          </div>

          {/* Seller inbox */}
          {isSeller && (
            <div className={styles.panel}>
              <p className={styles.panelTitle}>
                <i className="ri-inbox-2-line" /> Buy Requests ({allRequests.length})
              </p>

              {allRequests.length === 0 && (
                <div className={styles.inboxEmpty}>
                  <i className="ri-mail-line" />
                  <p>No requests yet.</p>
                </div>
              )}

              {allRequests.map(req => (
                <div key={req.id} className={styles.requestCard}>
                  <div className={styles.reqTop}>
                    <div className={styles.reqBuyerRow}>
                      <div className={styles.reqAvatar}>
                        {req.profiles?.avatar_url
                          ? <img src={req.profiles.avatar_url} alt="" className={styles.reqAvatarImg} />
                          : <span>{req.profiles?.username?.[0]?.toUpperCase() || '?'}</span>
                        }
                      </div>
                      <div>
                        <span className={styles.reqBuyer}>
                          {req.profiles?.username || 'Unknown'}
                          <UserBadges
                            email={req.profiles?.email}
                            countryFlag={req.profiles?.country_flag}
                            isSeasonWinner={req.profiles?.is_season_winner}
                            size={13}
                            gap={2}
                          />
                        </span>
                        <span className={styles.reqTier}>{req.profiles?.tier || ''}</span>
                      </div>
                    </div>
                    <span style={{ color: statusColor(req.status), fontSize: 10, fontWeight: 800, letterSpacing: '0.08em' }}>
                      {req.status?.toUpperCase()}
                    </span>
                  </div>

                  <div className={styles.reqPrice}>TZS {Number(req.offer_price).toLocaleString()}</div>
                  {req.note && <p className={styles.reqNote}>&quot;{req.note}&quot;</p>}

                  <div className={styles.reqActions}>
                    {req.status === 'pending' && (
                      <>
                        <button
                          className={styles.acceptBtn}
                          onClick={() => updateRequestStatus(req.id, 'accepted', req.buyer_id)}
                          disabled={updating}
                        >
                          <i className="ri-check-line" /> Accept
                        </button>
                        <button
                          className={styles.declineBtn}
                          onClick={() => updateRequestStatus(req.id, 'declined', req.buyer_id)}
                          disabled={updating}
                        >
                          <i className="ri-close-line" /> Decline
                        </button>
                      </>
                    )}
                    <Link href={`/shop/${id}/request/${req.id}`} className={styles.viewChatBtn}>
                      <i className="ri-chat-3-line" /> Chat
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── Lightbox ── */}
      {lightbox && (
        <div className={styles.lightbox} onClick={() => setLightbox(false)}>
          <button className={styles.lbClose} onClick={() => setLightbox(false)}>
            <i className="ri-close-line" />
          </button>
          {images.length > 1 && (
            <>
              <button
                className={`${styles.lbArrow} ${styles.lbArrowL}`}
                onClick={e => { e.stopPropagation(); setLbIdx(i => (i - 1 + images.length) % images.length) }}
              >
                <i className="ri-arrow-left-s-line" />
              </button>
              <button
                className={`${styles.lbArrow} ${styles.lbArrowR}`}
                onClick={e => { e.stopPropagation(); setLbIdx(i => (i + 1) % images.length) }}
              >
                <i className="ri-arrow-right-s-line" />
              </button>
            </>
          )}
          <img src={images[lbIdx]} alt="" className={styles.lbImg} onClick={e => e.stopPropagation()} />
          <p className={styles.lbCounter}>{lbIdx + 1} / {images.length}</p>
        </div>
      )}

      {/* ── Buy Now Modal ── */}
      {buyModal && (
        <div className={styles.modalOverlay} onClick={() => setBuyModal(false)}>
          <div className={styles.buyModalCard} onClick={e => e.stopPropagation()}>
            <button className={styles.buyModalClose} onClick={() => setBuyModal(false)}>
              <i className="ri-close-line" />
            </button>

            <div className={styles.buyModalIcon}><i className="ri-secure-payment-line" /></div>
            <h2 className={styles.buyModalTitle}>Complete Your Purchase</h2>
            <p className={styles.buyModalSub}>Send payment via M-Pesa or mobile money</p>

            <div className={styles.paymentBox}>
              <div className={styles.payRow}>
                <span className={styles.payLabel}>Pay to Number</span>
                <span className={styles.payValue}>0624003543</span>
              </div>
              <div className={styles.payRow}>
                <span className={styles.payLabel}>Account Name</span>
                <span className={styles.payValue}>Steven Msambwa</span>
              </div>
              <div className={styles.payRow}>
                <span className={styles.payLabel}>Amount</span>
                <span className={styles.payAmount}>TZS {fmtPrice(item.price)}</span>
              </div>
              <div className={styles.payRow}>
                <span className={styles.payLabel}>Reference</span>
                <span className={styles.payValue} style={{ fontSize: 12 }}>
                  {item.title.slice(0, 30)}
                </span>
              </div>
            </div>

            <div className={styles.sellerShareBox}>
              <i className="ri-information-line" />
              <p>
                After payment, the seller will share all required details — including account credentials,
                delivery info, or service instructions as applicable.
              </p>
            </div>

            <div className={styles.buyModalActions}>
              <Link
                href={`/shop/${id}/request/${myRequest?.id || ''}`}
                className={`${styles.primaryBtn} ${!myRequest ? styles.disabledBtn : ''}`}
                onClick={e => {
                  if (!myRequest) { e.preventDefault() }
                  else { setBuyModal(false) }
                }}
              >
                <i className="ri-chat-3-line" /> Chat Seller for Details
              </Link>
              <button className={styles.buyModalDone} onClick={() => setBuyModal(false)}>
                Done — I&apos;ve paid
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
