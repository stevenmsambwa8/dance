import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:app_links/app_links.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;

// ---------------------------------------------------------------------------
// GOOGLE SIGN-IN CONFIG
// Paste in your Web OAuth Client ID from Google Cloud Console (Credentials
// page — the "Web application" entry your Supabase Google provider already
// trusts). This is a public identifier, safe to ship in the app.
// ---------------------------------------------------------------------------
const String kGoogleWebClientId =
    '833730709330-99kn4jjg7kj257dn8q7t32am1fjrul7t.apps.googleusercontent.com';
const String kSupabaseUrl = 'https://whnsrbxeqorolkjfcniy.supabase.co';
const String kSupabaseAnonKey =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndobnNyYnhlcW9yb2xramZjbml5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzUwNjY3NzYsImV4cCI6MjA5MDY0Mjc3Nn0.7ZlmI1T8o-7Dm7BuUuG9wNWPaCU8yZ8O8pIFX5QBlx0';

// ---------------------------------------------------------------------------
// CONFIG — change these to re-skin the wrapper for another site/brand.
// ---------------------------------------------------------------------------
const String kSiteUrl = 'https://nabogaming.live';
const String kSiteHost = 'nabogaming.live';
const String kAppName = 'Nabogaming';
const Color kBrandColor = Color(0xFF2F9DA9); // matches your site's --accent
const Color kBgLight = Color(0xFFFFFFFF);
const Color kTextDark = Color(0xFF16161D);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  // Edge-to-edge so we can paint behind the notch/status bar and the bottom
  // system nav bar ourselves instead of leaving a default-white gap there.
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light, // splash bg is dark-ish teal
    statusBarBrightness: Brightness.dark,
    systemNavigationBarColor: kBrandColor,
    systemNavigationBarIconBrightness: Brightness.light,
    systemNavigationBarDividerColor: Colors.transparent,
  ));
  runApp(const NaboViewerApp());
}

class NaboViewerApp extends StatelessWidget {
  const NaboViewerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: kAppName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: kBrandColor,
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: kBgLight,
        useMaterial3: true,
      ),
      home: const WebViewShell(),
    );
  }
}

// Small JS injected after every page load to power pull-to-refresh. It only
// arms when the page is already scrolled to the very top, so it never fights
// normal in-page scrolling. Uses passive listeners so it can't block or slow
// down the page's own touch handling.
// Reports the site's current --bg CSS variable (set per-theme by
// ThemeProvider.js — light/dark/snow/neon/sunset/forest/gold/ocean all
// define it in globals.css) so the native app chrome can match, both on
// load and live if the user switches themes while the app is open.
const String _themeSyncJs = r'''
(function () {
  if (window.__naboThemeSyncInstalled) return;
  window.__naboThemeSyncInstalled = true;

  function report() {
    try {
      var bg = getComputedStyle(document.documentElement)
        .getPropertyValue('--bg').trim();
      if (bg && window.ThemeSync) window.ThemeSync.postMessage(bg);
    } catch (e) {}
  }

  report();
  new MutationObserver(report).observe(document.documentElement, {
    attributes: true,
    attributeFilter: ['data-theme'],
  });
})();
''';

const String _pullToRefreshJs = r'''
(function () {
  if (window.__naboPTRInstalled) return;
  window.__naboPTRInstalled = true;

  var startY = null;
  var pulling = false;
  var threshold = 70;
  var scrollTarget = null;

  function isScrollable(node) {
    if (!node || node === document.documentElement || node === document.body) {
      return false;
    }
    var style = getComputedStyle(node);
    return /(auto|scroll)/.test(style.overflowY) &&
      node.scrollHeight > node.clientHeight;
  }

  function findScrollParent(node) {
    while (node && node !== document.body && node !== document.documentElement) {
      if (isScrollable(node)) return node;
      node = node.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }

  function scrollTopOf(node) {
    if (node === document.scrollingElement || node === document.documentElement) {
      return window.scrollY || document.documentElement.scrollTop || 0;
    }
    return node.scrollTop;
  }

  var el = document.createElement('div');
  el.style.cssText = [
    'position:fixed', 'top:0', 'left:0', 'right:0', 'height:56px',
    'display:flex', 'align-items:center', 'justify-content:center',
    'transform:translateY(-56px)', 'transition:transform 0.15s ease-out',
    'z-index:2147483647', 'pointer-events:none'
  ].join(';');
  el.innerHTML =
    '<div style="width:30px;height:30px;border-radius:50%;background:#fff;' +
    'box-shadow:0 2px 8px rgba(0,0,0,0.22);display:flex;' +
    'align-items:center;justify-content:center;">' +
    '<div style="width:17px;height:17px;border-radius:50%;' +
    'border:2.5px solid #D8DCDD;border-top-color:#2F9DA9;"></div></div>';
  document.documentElement.appendChild(el);

  var spinning = false;
  function spin(on) {
    spinning = on;
    var ring = el.firstChild && el.firstChild.firstChild;
    if (!ring) return;
    ring.style.animation = on ? 'naboSpin 0.7s linear infinite' : 'none';
  }
  var styleTag = document.createElement('style');
  styleTag.innerHTML = '@keyframes naboSpin{to{transform:rotate(360deg)}}';
  document.head.appendChild(styleTag);

  document.addEventListener('touchstart', function (e) {
    // Only arm near the very top of the screen — avoids accidental
    // triggers from swipes that start mid-page.
    if (e.touches[0].clientY > 120) {
      pulling = false;
      startY = null;
      return;
    }
    scrollTarget = findScrollParent(e.target);
    if (scrollTopOf(scrollTarget) <= 0) {
      startY = e.touches[0].clientY;
      pulling = true;
    } else {
      startY = null;
      pulling = false;
    }
  }, { passive: true });

  document.addEventListener('touchmove', function (e) {
    if (!pulling || startY === null || spinning) return;
    // Re-check: if the tracked container has scrolled away from the top
    // mid-gesture (e.g. content shifted), abort instead of firing.
    if (scrollTopOf(scrollTarget) > 0) {
      pulling = false;
      el.style.transition = 'transform 0.15s ease-out';
      el.style.transform = 'translateY(-56px)';
      return;
    }
    var dy = e.touches[0].clientY - startY;
    if (dy > 0) {
      var offset = Math.min(dy / 1.6, 90);
      el.style.transition = 'none';
      el.style.transform = 'translateY(' + (offset - 56) + 'px)';
    }
  }, { passive: true });

  document.addEventListener('touchend', function (e) {
    if (!pulling || startY === null || spinning) { pulling = false; return; }
    var dy = (e.changedTouches[0].clientY - startY);
    el.style.transition = 'transform 0.15s ease-out';
    if (dy > threshold && scrollTopOf(scrollTarget) <= 0) {
      el.style.transform = 'translateY(0px)';
      spin(true);
      if (window.PullToRefresh) window.PullToRefresh.postMessage('refresh');
    } else {
      el.style.transform = 'translateY(-56px)';
    }
    pulling = false;
    startY = null;
  }, { passive: true });
})();
''';

class WebViewShell extends StatefulWidget {
  const WebViewShell({super.key});

  @override
  State<WebViewShell> createState() => _WebViewShellState();
}

class _WebViewShellState extends State<WebViewShell>
    with WidgetsBindingObserver {
  late final WebViewController _controller;

  bool _pageLoaded = false;
  bool _minSplashDone = false;
  bool _pageFailed = false;
  bool _isOffline = false;

  bool get _showSplash => !_pageFailed && (!_pageLoaded || !_minSplashDone);

  // Synced live from the website's own theme (see _themeSyncJs); defaults to
  // its light theme's colors until the first report arrives.
  Color _siteBgColor = kBgLight;
  bool _siteIsDark = false;

  // Set true right before sending the user to Google's sign-in page in an
  // external Custom Tab; used to auto-refresh the WebView once they come
  // back, so a freshly-created session shows up without them having to
  // manually pull-to-refresh.
  bool _pendingAuthReturn = false;

  final AppLinks _appLinks = AppLinks();
  StreamSubscription<Uri>? _linkSub;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initWebView();
    // Splash stays up for at least 2s regardless of how fast the page loads,
    // so it never flashes off before content is actually ready to show.
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() => _minSplashDone = true);
        _applySystemChrome();
      }
    });
    // Catches https://nabogaming.live/auth/... whenever Android hands it
    // back to this app instead of Chrome (see the App Links intent-filter
    // in AndroidManifest.xml) — covers both cold start and while running.
    _linkSub = _appLinks.uriLinkStream.listen((uri) {
      // Custom-scheme handoff from the Google sign-in flow: translate it
      // into loading the real callback URL inside the WebView, which is
      // where the PKCE code exchange actually needs to run.
      if (uri.scheme == 'nabogaming' && uri.host == 'auth-callback') {
        final code = uri.queryParameters['code'];
        _pendingAuthReturn = false;
        if (code != null) {
          _controller.loadRequest(
            Uri.parse('https://$kSiteHost/auth/confirm?code=$code'),
          );
        }
        return;
      }
      if (uri.host.contains(kSiteHost)) {
        _pendingAuthReturn = false;
        _controller.loadRequest(uri);
      }
    });
  }

  void _initWebView() {
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(kBgLight)
      ..setUserAgent(
        'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/124.0 Mobile Safari/537.36 $kAppName-App/1.0',
      )
      ..addJavaScriptChannel(
        'PullToRefresh',
        onMessageReceived: (_) => _controller.reload(),
      )
      ..addJavaScriptChannel(
        'ThemeSync',
        onMessageReceived: (message) => _handleThemeSync(message.message),
      )
      ..addJavaScriptChannel(
        'NabogamingNative',
        onMessageReceived: (message) {
          if (message.message == 'signInWithGoogle') {
            _signInWithGoogleNative();
          }
        },
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) {
            if (mounted) setState(() => _pageFailed = false);
          },
          onPageFinished: (_) {
            if (mounted) {
              setState(() => _pageLoaded = true);
              _applySystemChrome();
            }
            _controller.runJavaScript(_pullToRefreshJs);
            _controller.runJavaScript(_themeSyncJs);
          },
          onWebResourceError: (error) {
            if (error.isForMainFrame ?? true) {
              _handleLoadFailure();
            }
          },
          onNavigationRequest: (request) => _handleNavigation(request),
        ),
      )
      ..loadRequest(Uri.parse(kSiteUrl));
  }

  // Only consult connectivity when a load has actually failed — checking it
  // eagerly at startup is unreliable (it can briefly report "none" during
  // cold start before the radio settles).
  Future<void> _handleLoadFailure() async {
    final results = await Connectivity().checkConnectivity();
    final offline =
        results.isEmpty || results.every((r) => r == ConnectivityResult.none);
    if (mounted) {
      setState(() {
        _pageFailed = true;
        _isOffline = offline;
      });
      _applySystemChrome();
    }
  }

  bool _googleSignInReady = false;

  Future<void> _signInWithGoogleNative() async {
    try {
      if (!_googleSignInReady) {
        await GoogleSignIn.instance.initialize(
          serverClientId: kGoogleWebClientId,
        );
        _googleSignInReady = true;
      }

      final account = await GoogleSignIn.instance.authenticate();
      final idToken = account.authentication.idToken;
      if (idToken == null) {
        throw Exception('No ID token returned from Google.');
      }

      final response = await http.post(
        Uri.parse('$kSupabaseUrl/auth/v1/token?grant_type=id_token'),
        headers: {
          'apikey': kSupabaseAnonKey,
          'Content-Type': 'application/json',
        },
        body: jsonEncode({'provider': 'google', 'id_token': idToken}),
      );

      if (response.statusCode != 200) {
        throw Exception(
            'Sign-in failed (${response.statusCode}): ${response.body}');
      }

      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final accessToken = data['access_token'] as String?;
      final refreshToken = data['refresh_token'] as String?;
      if (accessToken == null || refreshToken == null) {
        throw Exception('Missing tokens in Supabase response.');
      }

      // Hands the session to the website's own Supabase client — see
      // window.__nativeGoogleLogin in lib/supabase.js on the website.
      final js = 'window.__nativeGoogleLogin &&'
          ' window.__nativeGoogleLogin(${jsonEncode(accessToken)}, ${jsonEncode(refreshToken)});';
      await _controller.runJavaScript(js);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Google sign-in failed: $e')),
        );
      }
    }
  }

  bool _isSpecialScheme(Uri uri) {
    return uri.scheme == 'tel' ||
        uri.scheme == 'mailto' ||
        uri.scheme == 'whatsapp' ||
        uri.scheme == 'intent';
  }

  // Keep normal browsing inside the app if it's on our domain. Everything
  // else off-domain over http/https — including your Supabase auth
  // authorize endpoint and Google's own consent screen, wherever they land
  // in the redirect chain — goes to a Chrome Custom Tab. Real Chrome, not a
  // WebView, so Google allows sign-in there; it also overlays on top of the
  // app instead of leaving it entirely. tel:/mailto:/whatsapp:/intent: go
  // straight to the OS as before.
  Future<NavigationDecision> _handleNavigation(
      NavigationRequest request) async {
    final uri = Uri.tryParse(request.url);
    if (uri == null) return NavigationDecision.navigate;

    final isOnSite = uri.host.isEmpty || uri.host.contains(kSiteHost);

    if (isOnSite && !_isSpecialScheme(uri)) {
      return NavigationDecision.navigate;
    }

    if (_isSpecialScheme(uri)) {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
      return NavigationDecision.prevent;
    }

    if (uri.scheme == 'http' || uri.scheme == 'https') {
      _pendingAuthReturn = true;
      try {
        await launchUrl(uri, mode: LaunchMode.inAppBrowserView);
      } catch (_) {
        if (await canLaunchUrl(uri)) {
          await launchUrl(uri, mode: LaunchMode.externalApplication);
        }
      }
      return NavigationDecision.prevent;
    }

    return NavigationDecision.prevent;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _pendingAuthReturn) {
      _pendingAuthReturn = false;
      _controller.reload();
    }
  }

  // Splash is a darker teal; the site's own background varies per theme.
  // Switch the system bars to match whichever is currently showing.
  void _applySystemChrome() {
    final onSplash = _showSplash;
    final navBarColor = onSplash ? kBrandColor : _siteBgColor;
    final lightIcons = onSplash ? true : _siteIsDark;
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: lightIcons ? Brightness.light : Brightness.dark,
      statusBarBrightness: lightIcons ? Brightness.dark : Brightness.light,
      systemNavigationBarColor: navBarColor,
      systemNavigationBarIconBrightness:
          lightIcons ? Brightness.light : Brightness.dark,
      systemNavigationBarDividerColor: Colors.transparent,
    ));
  }

  Color? _parseHexColor(String hex) {
    var h = hex.trim().replaceAll('#', '');
    if (h.length == 3) {
      h = h.split('').map((c) => c + c).join();
    }
    if (h.length != 6) return null;
    final value = int.tryParse(h, radix: 16);
    if (value == null) return null;
    return Color(0xFF000000 | value);
  }

  void _handleThemeSync(String hex) {
    final color = _parseHexColor(hex);
    if (color == null) return;
    final isDark = color.computeLuminance() < 0.5;
    if (color == _siteBgColor && isDark == _siteIsDark) return;
    if (mounted) {
      setState(() {
        _siteBgColor = color;
        _siteIsDark = isDark;
      });
    }
    _controller.setBackgroundColor(color);
    if (!_showSplash) _applySystemChrome();
  }

  Future<void> _retry() async {
    setState(() {
      _pageFailed = false;
      _isOffline = false;
      _pageLoaded = false;
      _minSplashDone = false;
    });
    _applySystemChrome();
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() => _minSplashDone = true);
        _applySystemChrome();
      }
    });
    await _controller.reload();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _linkSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        if (await _controller.canGoBack()) {
          _controller.goBack();
        } else {
          if (context.mounted) {
            final shouldExit = await _confirmExit(context);
            if (shouldExit && context.mounted) {
              SystemNavigator.pop();
            }
          }
        }
      },
      child: Scaffold(
        backgroundColor: _showSplash ? kBrandColor : _siteBgColor,
        body: Stack(
          children: [
            SafeArea(
              bottom: false,
              child: !_pageFailed
                  ? WebViewWidget(controller: _controller)
                  : (_isOffline
                      ? _OfflineView(onRetry: _retry)
                      : _ErrorView(onRetry: _retry)),
            ),
            // Full-bleed, outside SafeArea, so it covers the notch/status
            // bar and bottom nav bar too instead of leaving a white gap.
            if (_showSplash)
              const Positioned.fill(child: _SplashOverlay()),
          ],
        ),
      ),
    );
  }

  Future<bool> _confirmExit(BuildContext context) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: kBgLight,
        title: const Text('Exit app?', style: TextStyle(color: kTextDark)),
        content: const Text(
          'Are you sure you want to close the app?',
          style: TextStyle(color: Colors.black54),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Exit'),
          ),
        ],
      ),
    );
    return result ?? false;
  }
}

class _SplashOverlay extends StatelessWidget {
  const _SplashOverlay();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: kBrandColor,
      alignment: Alignment.center,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(
            'assets/icon/logo.png',
            width: 120,
            height: 120,
          ),
          const SizedBox(height: 28),
          const SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(
              strokeWidth: 2.4,
              valueColor: AlwaysStoppedAnimation(Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}

class _OfflineView extends StatelessWidget {
  final Future<void> Function() onRetry;
  const _OfflineView({required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return _MessageView(
      icon: Icons.wifi_off_rounded,
      title: 'No internet connection',
      message: 'Check your connection and try again.',
      onRetry: onRetry,
    );
  }
}

class _ErrorView extends StatelessWidget {
  final Future<void> Function() onRetry;
  const _ErrorView({required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return _MessageView(
      icon: Icons.error_outline_rounded,
      title: "Couldn't load $kAppName",
      message: 'Something went wrong loading the page.',
      onRetry: onRetry,
    );
  }
}

class _MessageView extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final Future<void> Function() onRetry;

  const _MessageView({
    required this.icon,
    required this.title,
    required this.message,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: kBgLight,
      alignment: Alignment.center,
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 56, color: Colors.black26),
          const SizedBox(height: 16),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: kTextDark,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            message,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.black54, fontSize: 14),
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: onRetry,
            style: ElevatedButton.styleFrom(
              backgroundColor: kBrandColor,
              foregroundColor: Colors.white,
              padding:
                  const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  }
}
