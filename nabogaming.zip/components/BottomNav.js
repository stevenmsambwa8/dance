'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useState, useEffect } from 'react'
import { useAuth } from './AuthProvider'
import { supabase } from '../lib/supabase'
import styles from './BottomNav.module.css'

// Integrated all 5 items together to match Spotify's premium layout symmetry
const navLinks = [
  { href: '/',            label: 'Home',        icon: 'ri-stack-line',     iconActive: 'ri-stack-fill' },
  { href: '/tournaments', label: 'Tournaments', icon: 'ri-trophy-line',    iconActive: 'ri-trophy-fill' },
  { href: '/games',       label: 'Games',       icon: 'ri-gamepad-line',   iconActive: 'ri-gamepad-fill', big: true },
  { href: '/season',      label: 'Season',      icon: 'ri-dashboard-line', iconActive: 'ri-dashboard-fill' },
  { href: '/feed',        label: 'Feed',        icon: 'ri-compass-3-line', iconActive: 'ri-compass-3-fill' },
]

export default function BottomNav() {
  const path = usePathname()
  const { user } = useAuth()
  const [unread, setUnread] = useState(0)

  useEffect(() => {
    if (!user) { setUnread(0); return }
    supabase
      .from('notifications')
      .select('id', { count: 'exact', head: true })
      .eq('user_id', user.id)
      .eq('read', false)
      .then(({ count }) => setUnread(count || 0))

    const channel = supabase
      .channel('bottom-nav-notifs')
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'notifications',
        filter: `user_id=eq.${user.id}`,
      }, () => setUnread(n => n + 1))
      .subscribe()
    return () => supabase.removeChannel(channel)
  }, [user])

  return (
    <nav className={styles.wrapper}>
      <div className={styles.container}>
        {navLinks.map(({ href, label, icon, iconActive, big }) => {
          const isActive = href === '/' ? path === '/' : path.startsWith(href)

          return (
            <Link 
              key={href} 
              href={href} 
              className={`${styles.item} ${isActive ? styles.active : ''} ${big ? styles.itemBig : ''}`}
              aria-label={label}
            >
              <span className={styles.iconWrap}>
                <i className={isActive ? iconActive : icon} />
                {href === '/' && unread > 0 && <span className={styles.navBadge} />}
              </span>
              {!big && <span className={styles.label}>{label}</span>}
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
