'use client'
import { useState, useEffect, useRef } from 'react'
import Modal from '../../components/Modal'
import { useAuth } from '../../components/AuthProvider'
import { useAuthGate } from '../../components/AuthGateModal'
import { supabase } from '../../lib/supabase'
import styles from './page.module.css'
import UserBadges from '../../components/UserBadges'
import usePageLoading from '../../components/usePageLoading'

export default function Feed() {
  const { user, profile, isAdmin } = useAuth()
  const { openAuthGate } = useAuthGate()
  const [posts, setPosts] = useState([])
  const [liked, setLiked] = useState({})
  const [selected, setSelected] = useState(null)
  const [comment, setComment] = useState('')
  const [comments, setComments] = useState([])
  const [newPost, setNewPost] = useState('')
  const [postModal, setPostModal] = useState(false)
  const [loading, setLoading] = useState(true)
  usePageLoading(loading)
  const [submitting, setSubmitting] = useState(false)
  const [postError, setPostError] = useState('')
  const textareaRef = useRef(null)
  const [likersOpen, setLikersOpen] = useState(false)
  const [likersLoading, setLikersLoading] = useState(false)
  const [likers, setLikers] = useState([])
  const [following, setFollowing] = useState({})
  const [topLikers, setTopLikers] = useState({})

  useEffect(() => { loadPosts() }, [])

  async function loadPosts() {
    setLoading(true)
    const { data, error } = await supabase
      .from('posts')
      .select('id, user_id, content, likes, comment_count, created_at, profiles(id, username, tier, level, avatar_url, email, plan, plan_expires_at, game_tags, country_flag, is_season_winner, custom_badges, temp_admin_until)')
      .order('created_at', { ascending: false })
      .limit(50)
    if (!error) setPosts(data || [])
    setLoading(false)
  }

  async function openPost(post) {
    setSelected(post)
    const { data } = await supabase
      .from('comments')
      .select('id, post_id, user_id, text, created_at, profiles(username, avatar_url)')
      .eq('post_id', post.id)
      .order('created_at', { ascending: true })
    const list = data || []
    setComments(list)
    // Self-heal: the stored comment_count can drift from reality (deleted
    // rows, failed increments elsewhere) — reconcile it against what we
    // actually just fetched so the count shown on the post is trustworthy.
    if (list.length !== (post.comment_count || 0)) {
      setPosts(p => p.map(x => x.id === post.id ? { ...x, comment_count: list.length } : x))
      setSelected(s => s && s.id === post.id ? { ...s, comment_count: list.length } : s)
      await supabase.from('posts').update({ comment_count: list.length }).eq('id', post.id)
    }
  }

  async function openLikers(post) {
    setLikersOpen(true)
    setLikersLoading(true)
    const { data } = await supabase
      .from('post_likes')
      .select('user_id, profiles(username, avatar_url)')
      .eq('post_id', post.id)
    setLikers(data || [])
    setLikersLoading(false)
  }

  async function toggleLike(post) {
    if (!user) return alert('Log in to like posts')
    const isLiked = liked[post.id]
    setLiked(l => ({ ...l, [post.id]: !isLiked }))
    const newLikes = post.likes + (isLiked ? -1 : 1)
    setPosts(p => p.map(x => x.id === post.id ? { ...x, likes: newLikes } : x))
    if (isLiked) {
      await supabase.from('post_likes').delete().eq('post_id', post.id).eq('user_id', user.id)
    } else {
      await supabase.from('post_likes').insert({ post_id: post.id, user_id: user.id })
    }
    await supabase.from('posts').update({ likes: newLikes }).eq('id', post.id)
  }

  async function deletePost(post) {
    if (!user) return
    const canDelete = user.id === post.user_id || isAdmin
    if (!canDelete) return
    if (!confirm('Delete this post?')) return
    const { error } = await supabase.from('posts').delete().eq('id', post.id)
    if (!error) {
      setPosts(p => p.filter(x => x.id !== post.id))
      if (selected?.id === post.id) setSelected(null)
    }
  }

  async function addComment() {
    if (!comment.trim() || !selected || !user) return
    const { data } = await supabase
      .from('comments')
      .insert({ post_id: selected.id, user_id: user.id, text: comment.trim() })
      .select('id, post_id, user_id, text, created_at, profiles(username, avatar_url)')
      .single()
    if (data) setComments(c => [...c, data])
    setPosts(p => p.map(x => x.id === selected.id ? { ...x, comment_count: (x.comment_count || 0) + 1 } : x))
    setComment('')
  }

  async function submitPost() {
    if (!newPost.trim()) return
    if (!user) { setPostError('You must be logged in to post.'); return }
    setPostError('')
    setSubmitting(true)
    const { data, error } = await supabase
      .from('posts')
      .insert({ user_id: user.id, content: newPost.trim(), likes: 0, comment_count: 0 })
      .select('id, user_id, content, likes, comment_count, created_at, profiles(id, username, tier, level, avatar_url, email, plan, plan_expires_at, game_tags, country_flag, is_season_winner, custom_badges, temp_admin_until)')
      .single()
    if (error) {
      setPostError(error.message)
    } else if (data) {
      setPosts(p => [data, ...p])
      setNewPost('')
      setPostModal(false)
    }
    setSubmitting(false)
  }

  useEffect(() => {
    if (!user || posts.length === 0) return
    supabase.from('post_likes').select('post_id').eq('user_id', user.id)
      .then(({ data }) => {
        if (!data) return
        const map = {}
        data.forEach(l => { map[l.post_id] = true })
        setLiked(map)
      })
  }, [user, posts.length])

  useEffect(() => {
    if (!user || posts.length === 0) return
    const authorIds = [...new Set(posts.map(p => p.user_id).filter(id => id && id !== user.id))]
    if (authorIds.length === 0) return
    supabase.from('follows').select('following_id').eq('follower_id', user.id).in('following_id', authorIds)
      .then(({ data }) => {
        if (!data) return
        const map = {}
        data.forEach(f => { map[f.following_id] = true })
        setFollowing(f => ({ ...f, ...map }))
      })
  }, [user, posts.length])

  useEffect(() => {
    const likedPostIds = posts.filter(p => p.likes > 0).map(p => p.id)
    if (likedPostIds.length === 0) return
    supabase.from('post_likes').select('post_id, profiles(username)').in('post_id', likedPostIds)
      .then(({ data }) => {
        if (!data) return
        const map = {}
        data.forEach(l => { if (!map[l.post_id]) map[l.post_id] = l.profiles?.username || 'Player' })
        setTopLikers(m => ({ ...m, ...map }))
      })
  }, [posts.length])

  async function toggleFollow(authorId) {
    if (!user) return openAuthGate()
    if (!authorId || authorId === user.id) return
    const isFollowing = following[authorId]
    setFollowing(f => ({ ...f, [authorId]: !isFollowing }))
    if (isFollowing) {
      await supabase.from('follows').delete().eq('follower_id', user.id).eq('following_id', authorId)
    } else {
      await supabase.from('follows').insert({ follower_id: user.id, following_id: authorId })
    }
  }

  const ADMIN_EMAIL = 'stevenmsambwa8@gmail.com'

  function isPostVerified(post) {
    return post.profiles?.email === ADMIN_EMAIL
  }

  return (
    <div className={styles.page}>
      {user ? (
        <div className={styles.composeBar} onClick={() => setPostModal(true)}>
          <span className={styles.composePlaceholder}>What&apos;s on your mind, {profile?.username || 'Player'}?</span>
          <button className={styles.composeBtn}>Post</button>
        </div>
      ) : (
        <p className={styles.loginPrompt}><button onClick={openAuthGate} style={{background:'none',border:'none',color:'inherit',fontWeight:700,cursor:'pointer',padding:0,textDecoration:'underline',fontFamily:'var(--font)'}}>Log in</button> to post and interact.</p>
      )}

      {!loading && (
        <div className={styles.feed}>
          {posts.length === 0 && <p className={styles.empty}>No posts yet. Be the first!</p>}
          {posts.map(post => (
            <div key={post.id} className={styles.post}>
              <div className={styles.postRow}>
                <a href={`/profile/${post.profiles?.id}`} className={styles.avatarLink}>
                  <div className={styles.avatar}>
                    {post.profiles?.avatar_url
                      ? <img src={post.profiles.avatar_url} alt="" className={styles.avatarImg} />
                      : <span>{(post.profiles?.username || 'P').slice(0, 2).toUpperCase()}</span>
                    }
                  </div>
                </a>
                <div className={styles.postBody}>
                  <div className={styles.postHeader}>
                    <div className={styles.postUserRow}>
                      <a href={`/profile/${post.profiles?.id}`} className={styles.postUser}>{post.profiles?.username || 'Player'}</a>
                      <UserBadges email={post.profiles?.email} plan={post.profiles?.plan} planExpiresAt={post.profiles?.plan_expires_at} countryFlag={post.profiles?.country_flag} isSeasonWinner={post.profiles?.is_season_winner} customBadges={post.profiles?.custom_badges} tempAdminUntil={post.profiles?.temp_admin_until} size={13} gap={2} />
                      {post.profiles?.level ? <span className={styles.postDot}>·</span> : null}
                      {post.profiles?.level ? <span className={styles.postTime}>Lv.{post.profiles.level}</span> : null}
                      <span className={styles.postDot}>·</span>
                      <span className={styles.postTime}>{timeAgo(post.created_at)}</span>
                    </div>
                    {user && (user.id === post.user_id || isAdmin) && (
                      <button className={styles.deleteBtn} onClick={() => deletePost(post)} title="Delete post">
                        <i className="ri-delete-bin-line" />
                      </button>
                    )}
                  </div>
                  {(post.profiles?.game_tags || []).length > 0 && (
                    <div className={styles.postTags}>
                      {post.profiles.game_tags.map(g => (
                        <span key={g} className={styles.postTag}>{g}</span>
                      ))}
                    </div>
                  )}
                  <p className={styles.postContent}>{post.content}</p>
                  <div className={styles.postActions}>
                    <div className={styles.actionsLeft}>
                      <button className={`${styles.action} ${liked[post.id] ? styles.liked : ''}`} onClick={() => toggleLike(post)}>
                        <i className={liked[post.id] ? 'ri-heart-fill' : 'ri-heart-line'} />
                        {post.likes || 0}
                      </button>
                      <button className={styles.action} onClick={() => openPost(post)}>
                        <i className="ri-chat-1-line" />
                        {post.comment_count || 0}
                      </button>
                    </div>
                    <div className={styles.actionsRight}>
                      <button className={styles.action} onClick={() => navigator.share?.({ text: post.content })}>
                        <i className="ri-share-forward-line" />
                      </button>
                      {user && user.id !== post.user_id && (
                        <button
                          className={`${styles.followBtn} ${following[post.user_id] ? styles.followingBtn : ''}`}
                          onClick={() => toggleFollow(post.user_id)}
                        >
                          {following[post.user_id] ? 'Following' : 'Follow'}
                        </button>
                      )}
                    </div>
                  </div>
                  {post.likes > 0 && (
                    <button className={styles.likesCaption} onClick={() => openLikers(post)}>
                      Liked by {topLikers[post.id] || 'someone'}{post.likes > 1 ? ` and ${post.likes - 1} ${post.likes - 1 === 1 ? 'other' : 'others'}` : ''}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Comments Modal */}
      <Modal
        open={!!selected}
        onClose={() => { setSelected(null); setComment('') }}
        title={selected ? `${comments.length} Comment${comments.length === 1 ? '' : 's'}` : ''}
        size="md"
        footer={
          user ? (
            <div className={styles.commentInput}>
              <input
                value={comment}
                onChange={e => setComment(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addComment()}
                placeholder="Write a comment..."
              />
              <button onClick={addComment}><i className="ri-send-plane-fill" /></button>
            </div>
          ) : <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>Log in to comment</p>
        }
      >
        {selected && (
          <div className={styles.commentBody}>
            <p className={styles.modalPost}>{selected.content}</p>
            <div className={styles.comments}>
              {comments.length === 0 && <p className={styles.noComments}>No comments yet.</p>}
              {comments.map((c) => (
                <div key={c.id} className={styles.comment}>
                  <span className={styles.commentUser}>{c.profiles?.username || 'Player'}</span>
                  <span className={styles.commentText}>{c.text}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </Modal>

      {/* Likes Modal — Instagram-style list of who liked the post */}
      <Modal
        open={likersOpen}
        onClose={() => { setLikersOpen(false); setLikers([]) }}
        title="Likes"
        size="md"
      >
        {likersLoading ? (
          <p className={styles.noComments}>Loading…</p>
        ) : likers.length === 0 ? (
          <p className={styles.noComments}>No likes yet.</p>
        ) : (
          <div className={styles.likersList}>
            {likers.map((l, i) => (
              <a key={l.user_id || i} href={`/profile/${l.user_id}`} className={styles.likerRow}>
                <div className={styles.likerAvatar}>
                  {l.profiles?.avatar_url
                    ? <img src={l.profiles.avatar_url} alt="" className={styles.avatarImg} />
                    : <span>{(l.profiles?.username || 'P').slice(0, 2).toUpperCase()}</span>
                  }
                </div>
                <span className={styles.likerName}>{l.profiles?.username || 'Player'}</span>
              </a>
            ))}
          </div>
        )}
      </Modal>

      {/* New Post Modal */}
      <Modal
        open={postModal}
        onClose={() => { setPostModal(false); setPostError('') }}
        title="New Post"
        size="md"
        footer={
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, width: '100%' }}>
            {postError && <p style={{ color: '#ef4444', fontSize: '0.8rem' }}>{postError}</p>}
            <button onClick={submitPost} disabled={submitting || !newPost.trim()} style={{ marginLeft: 'auto', padding: '9px 22px', background: 'var(--accent)', color: '#fff', border: 'none', borderRadius: 9999, cursor: 'pointer', fontWeight: 800, fontSize: 14, opacity: submitting || !newPost.trim() ? 0.5 : 1 }}>
              {submitting ? 'Posting…' : 'Post'}
            </button>
          </div>
        }
      >
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
          <div style={{ width: 42, height: 42, borderRadius: '50%', background: 'var(--text)', color: 'var(--bg)', fontSize: 12, fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, overflow: 'hidden' }}>
            {profile?.avatar_url
              ? <img src={profile.avatar_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              : <span>{(profile?.username || 'P').slice(0, 2).toUpperCase()}</span>
            }
          </div>
          <textarea
            ref={textareaRef}
            style={{ flex: 1, width: '100%', background: 'none', border: 'none', color: 'var(--text)', padding: 0, fontSize: '1rem', lineHeight: 1.4, resize: 'vertical', fontFamily: 'inherit', outline: 'none', minHeight: 100 }}
            value={newPost}
            onChange={e => setNewPost(e.target.value)}
            placeholder={`What's happening, ${profile?.username || 'Player'}?`}
            rows={5}
            autoFocus
          />
        </div>
      </Modal>
    </div>
  )
}

function timeAgo(iso) {
  const diff = (Date.now() - new Date(iso)) / 1000
  if (diff < 60) return 'just now'
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`
  return `${Math.floor(diff / 86400)}d ago`
}
